﻿using UnityEngine;
using System.Collections;

public enum UseableItem
{
	None,
	Rock,
	Paper,
	Scissors
}